
export class Artist{
    id?:number;
    name?: string;
    avatar?:string;
    country?:string;
}