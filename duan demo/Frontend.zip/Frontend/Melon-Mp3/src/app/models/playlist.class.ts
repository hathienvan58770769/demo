
export class Playlist{
    id?:number;
    name?: string;
    avatar?:string;
}