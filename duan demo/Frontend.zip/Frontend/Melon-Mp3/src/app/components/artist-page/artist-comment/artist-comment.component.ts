import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-artist-comment',
  templateUrl: './artist-comment.component.html',
  styleUrls: ['./artist-comment.component.css']
})
export class ArtistCommentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
