import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-playlist-add-song',
  templateUrl: './playlist-add-song.component.html',
  styleUrls: ['./playlist-add-song.component.css']
})
export class PlaylistAddSongComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
