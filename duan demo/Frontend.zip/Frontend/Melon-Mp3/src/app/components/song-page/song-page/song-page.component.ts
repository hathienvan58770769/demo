import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-song-page',
  templateUrl: './song-page.component.html',
  styleUrls: ['./song-page.component.css']
})
export class SongPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
