package codegym.mp3zingservice;

public class DemoWeb {
}
