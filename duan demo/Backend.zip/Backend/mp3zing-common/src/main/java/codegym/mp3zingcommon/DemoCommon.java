package codegym.mp3zingcommon;

public class DemoCommon {
}
